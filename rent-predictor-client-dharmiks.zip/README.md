# Rent Predictor Application Using: React & Flask
[Link to hosted application](https://predict-rent-dharmik.netlify.app/)